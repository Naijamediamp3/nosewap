This is Nose Swap

CTCTM, CTC7
https://bscscan.com/token/0xBa6fF8E1Aa241a8a23323C2411B6888b6a998579
https://bscscan.com/token/0x7e41E454b6A29C54e4cDB565E47542f4BCb37ef1
