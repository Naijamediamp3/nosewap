module.exports = {
  content: ["./src/**/*.{html,js}"],
  theme: {
    extend: {},
    // colors: {
    //   'primary': '#1F2630',
    //   'secondary': '#F4BC1D'
    // },
  },
  plugins: [],
}
