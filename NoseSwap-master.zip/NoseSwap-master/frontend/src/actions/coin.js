import api from '../utils/api';
/*
  NOTE: we don't need a config object for axios as the
 default headers in axios are already Content-Type: application/json
 also axios stringifies and parses JSON for you, so no need for 
 JSON.stringify or JSON.parse
*/

// Load User
export const AllCoinInfo = () => async (dispatch) => {
  try {
    const res = await api.post('/coin');

    // console.log("AllCoinInfo:",res);

    return ({status:200},res);
  } catch (err) {
    // console.log("AllCoinInfo error",err);
    return ({status:400});
  }
};

export const CoinInfoBySymbol = (formData) => async (dispatch) => {
  try {
    const {symbol} = formData;
    // console.log('/coin/'+symbol);
    const res = await api.post('/coin/'+symbol);

    // console.log("CoinInfoBySymbol:",res);

    return ({status:200},res);
  } catch (err) {
    // console.log("CoinInfoBySymbol error",err);
    return ({status:400});
  }
};

export const calcFeeBySymbol = (formData) => async (dispatch) => {
  try {
    const { symbol, staking_amount } = formData
    const res = await api.post('/coin/calcFee/'+symbol+'/'+staking_amount);
    return res;
  } catch (err) {
    return ({status:400});
  }
}

export const addCTCTM = (formData) => async (dispatch) => {
  try {
    const { account, value } = formData;
    console.log(account, value);
    const res = await api.post('/coin/sendCTCTMtoUer', { toAddress: account, amount: value});
    return res;
  } catch (error) {
    return ({status: 400});
  }
}

export const addStakingValue = (formData) => async (dispatch) => {
  try {
    const { address, symbol, staking_amount } = formData
    const res = await api.post('/coin/addStaking/'+address+'/'+symbol+'/'+staking_amount);
    return res;
  } catch (err) {
    return ({status:400});
  }
}

export const SetCoin_StakedValue = (formData) => async (dispatch) => {
  try {
    const {symbol} = formData;
    // console.log('/coin/'+symbol);
    const res = await api.post('/coin/'+symbol);

    // console.log("CoinInfoBySymbol:",res);

    return ({status:200},res);
  } catch (err) {
    // console.log("CoinInfoBySymbol error",err);
    return ({status:400});
  }
};