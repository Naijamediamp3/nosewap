// constants
import Web3EthContract from "web3-eth-contract";
import Web3 from "web3";
import SmartContract from "../contracts/NoseStaking.json";
// import address from "../contracts/contract-address.json";
import chain from "../contracts/chain.json";
import Bep20ABI from "../contracts/BEP20.json";
import CTCTM from "../contracts/CTCTM.json";
import CTC7 from "../contracts/CTC7.json";
import SimpleJson from "../contracts/Simple.json";
import settings from "../contracts/default.json";

import { isEmptyObject } from "../components/common/common";
// This function detects most providers injected at window.ethereum
import detectEthereumProvider from "@metamask/detect-provider";
// log
// import { fetchData } from "../data/dataActions";
import getWeb3 from "./../getWeb3";

const connectRequest = () => {
  return {
    type: "CONNECTION_REQUEST",
  };
};

const connectSuccess = (payload) => {
  return {
    type: "CONNECTION_SUCCESS",
    payload: payload,
  };
};

const connectFailed = (payload) => {
  return {
    type: "CONNECTION_FAILED",
    payload: payload,
  };
};

const chainChanged = (payload) => {
  console.log("chainChanged");
  return {
    type: "CONNECTION_ChainChanged",
    payload: payload,
  };
};

const disConnect = (payload) => {
  return {
    type: "Disconnect",
    payload: payload,
  };
};

const updateAccountRequest = (payload) => {
  return {
    type: "UPDATE_ACCOUNT",
    payload: payload,
  };
};

export const networkId = (provider) => async (dispatch) => {
  try {
    const web3 = new Web3(provider);
    const networkId = await web3.eth.getChainId();
    return { status: "success", networkId: networkId };
  } catch {
    return { status: "failed" };
  }
};

export const connect = (provider) => {
  console.log("--:");
  const coinChain = settings.chain_name;
  const chainData = chain[coinChain][settings.netSetting];
  return async (dispatch) => {
    // const { ethereum } = window;
    // const metamaskIsInstalled = ethereum && ethereum.isMetaMask;
    // Web3EthContract.setProvider(ethereum);

    try {
      dispatch(connectRequest());
      const web3 = new Web3(provider);
      const accounts = await web3.eth.getAccounts();

      //switch chain
      await dispatch(switchChain(provider, coinChain));
      //get networkId
      const networkId = await web3.eth.getChainId();

      // const NetworkData = await SmartContract.networks[networkId];
      const resultethereum = await dispatch(
        connectContractUsingethereum(coinChain, provider)
      );

      dispatch(
        connectSuccess({
          account: accounts[0],
          smartContract: resultethereum.SmartContractObj,
          web3: resultethereum.web3,
        })
      );
      return { status: "success" };
    } catch (error) {
      dispatch(connectFailed({ errorMsg: "Something went wrong." }));
    }
    return { status: "failed" };
  };
};

export const calcFeeBySymbol =
  (chain_Name, coin_symbol, staking_amount) => async (dispatch) => {
    try {
      staking_amount = Web3.utils.toWei(staking_amount, "ether");
      const SmartContractObj = (
        await dispatch(connectContractUsingprovider(chain_Name))
      ).SmartContractObj;
      const result = await SmartContractObj.methods
        .calcFeeBySymbol(coin_symbol, staking_amount)
        .call()
        .catch((error) => {
          return { status: "failed", error };
        });
      const _staked_val = Web3.utils.fromWei(result._staked_val, "ether");
      const fee = Web3.utils.fromWei(result.fee, "ether");
      return {
        status: "success",
        _staked_val: _staked_val,
        fee: fee,
        fee_divider: result.fee_divider,
      };
    } catch {
      return { status: "failed" };
    }
  };

export const connectContract = (chain_Name, provider) => async (dispatch) => {
  console.log(
    "----------------ConnectContract--------------:chain_name",
    chain_Name
  );
  if (chain_Name === "") return { status: "failed" };

  const SmartContractObj = (
    await dispatch(connectContractUsingprovider(chain_Name, provider))
  ).SmartContractObj;
  console.log("connectContract", SmartContractObj);
  return { status: "success", SmartContractObj };
};

export const connectWallet = async (provider) => {
  //using by getAccount
  try {
    const web3 = new Web3(provider);
    const accounts = await web3.eth.getAccounts();
    return { status: "success", accounts };
  } catch (error) {
    return { status: "failed", error };
  }
};

//params: ChainName:ethereum, binance
export const isconnected = async (provider) => {
  try {
    const web3 = new Web3(provider);
    const accounts = await web3.eth.getAccounts();
    if (isEmptyObject(accounts) !== false) return { status: "failed" };
    return { status: "success", accounts };
  } catch (error) {
    return { status: "failed", error };
  }
};

export const connectContractByContractAddress =
  (provider, coin_chain, contract_address) => async (dispatch) => {
    console.log("---------------ConnectContractByAddress----------------");
    if (contract_address === "") return { status: "failed" };

    try {
      const web3 = new Web3(provider);
      console.log(await dispatch(networkId()));
      const SmartContractObj = new web3.eth.Contract(
        Bep20ABI,
        contract_address
      );
      return { status: "success", SmartContractObj };
    } catch (error) {
      return { status: "failed", error };
    }
  };

export const connectContractUsingprovider =
  (chain_Name, provider) => async (dispatch) => {
    const chainData = chain[chain_Name][settings.netSetting];
    try {
      const web3 = new Web3(new Web3.providers.HttpProvider(chainData.rpcUrls));

      const SmartContractObj = new web3.eth.Contract(
        SmartContract.abi,
        chainData.contract
      );
      return { status: "success", SmartContractObj, web3 };
    } catch {
      return { status: "failed" };
    }
  };

export const connectContractUsingethereum =
  (chain_Name, provider) => async (dispatch) => {
    const chainData = chain[chain_Name][settings.netSetting];
    try {
      const web3 = new Web3(provider);

      const SmartContractObj = new web3.eth.Contract(
        SmartContract.abi,
        chainData.contract
      );
      return { status: "success", SmartContractObj, web3 };
    } catch {
      return { status: "failed" };
    }
  };

export const connectContractCTCTMContract = () => async (dispatch) => {
  const chainData = chain[settings.chain_name][settings.netSetting];
  try {
    const web3 = new Web3(new Web3.providers.HttpProvider(chainData.rpcUrls));

    const SmartContractObj = new web3.eth.Contract(
      CTCTM.abi,
      settings.CTCTM_Contract
    );
    return { status: "success", SmartContractObj, web3 };
  } catch {
    return { status: "failed" };
  }
};

export const connectContractCTCTMContractByethereum =
  (provider) => async (dispatch) => {
    const chainData = chain[settings.chain_name][settings.netSetting];
    try {
      const web3 = new Web3(provider);

      const SmartContractObj = new web3.eth.Contract(
        CTCTM.abi,
        settings.CTCTM_Contract
      );
      return { status: "success", SmartContractObj, web3 };
    } catch {
      return { status: "failed" };
    }
  };

//switch switchChain
export const switchChain = (provider, chain_Name) => async (dispatch) => {
  const chainData = chain[chain_Name][settings.netSetting];
  const networkId = Web3.utils.toHex(chainData.chainId);
  const chainName = chainData.chainName;
  const rpcUrls = chainData.rpcUrls;
  const blockExplorerUrls = chainData.blockExplorerUrls;
  const nativeCurrency = chainData.nativeCurrency;
  const contract_address = chainData.contract;

  const web3 = new Web3(provider);

  try {
    let currentChainId = await web3.eth.getChainId();
    currentChainId = Web3.utils.toHex(currentChainId);
    if (currentChainId !== networkId) {
      try {
        await web3.currentProvider
          .request({
            method: "wallet_switchEthereumChain",
            params: [{ chainId: Web3.utils.toHex(networkId) }],
          })
          .then(() => {
            return { status: "await" };
          });
      } catch (err) {
        // This error code indicates that the chain has not been added to MetaMask
        console.log(err);
        if (err.code === 4902 || err.code === -32603) {
          try {
            await web3.currentProvider.request({
              method: "wallet_addEthereumChain",
              params: [
                {
                  chainName: chainName,
                  chainId: Web3.utils.toHex(networkId),
                  nativeCurrency: {
                    name: nativeCurrency,
                    decimals: 18,
                    symbol: nativeCurrency,
                  },
                  rpcUrls: [rpcUrls],
                },
              ],
            });
          } catch (err) {
            return { status: "failed", err };
          }
        }
        if (err.code === 4001) {
          console.log("switch wallet error");
          return { status: "failed", err };
        }
      }
    }
    return { status: "success" };
  } catch (error) {
    return { status: "failed", error };
  }
};

//switch wallet using chainName, and dispatch(connectSuccess);
export const switchWallet = (provider, chain_Name) => async (dispatch) => {
  console.log("--------------switchWallet-------------");
  try {
    const web3 = new Web3(provider);
    //get by chainName and netSetting
    const chainData = chain[chain_Name][settings.netSetting];
    //Current ChainID
    const currentChainId = await web3.eth.getChainId();
    //check the status of connecting wallet
    let resultaccount = await isconnected(provider);
    if (
      currentChainId === Web3.utils.toHex(chainData.chainId) &&
      resultaccount.status === "success"
    ) {
      {
        const resultethereum = await dispatch(
          connectContractUsingethereum(chain_Name, provider)
        );
        dispatch(
          connectSuccess({
            account: resultaccount.accounts[0],
            smartContract: resultethereum.SmartContractObj,
          })
        );
      }
      return { status: "success", powerstatus: "success" };
    }
    // Switch to BSC CHAIN
    const resswitchwallet = await dispatch(switchChain(provider, chain_Name));
    if (resswitchwallet.status === "failed") {
      return { status: "failed" };
    }

    // connectSuccess, dispatch(blockchain)
    // connect Wallet and return account
    const res = await connectWallet(provider);
    if (res.status === "failed") {
      return { status: "failed" };
    }
    const accounts = res.accounts;

    const resultethereum = await dispatch(
      connectContractUsingethereum(chain_Name, provider)
    );
    dispatch(
      connectSuccess({
        account: accounts[0],
        smartContract: resultethereum.SmartContractObj,
      })
    );
    return { status: "success" };
  } catch (error) {
    return { status: "failed", error };
  }
};

export const Isallowance = (provider) => async (dispatch) => {
  const chainData = chain[settings.chain_name][settings.netSetting];
  try {
    const accounts = (await isconnected(provider)).accounts;
    const SmartContractObj = (await dispatch(connectContractCTCTMContract()))
      .SmartContractObj;

    // console.log("SmartContractObj, account:", SmartContractObj, accounts[0], settings.company_Wallet);

    const allow_value = await SmartContractObj.methods
      .allowance(accounts[0], chainData.contract)
      .call();
    return { status: "success", allow_value };
  } catch (err) {
    return { status: "failed", err };
  }
};

//Ethereum, Contract_address CTCTM approve
export const approve =
  (provider, coin_chain, staking_ctctmvalue) => async (dispatch) => {
    console.log("------------approve----------------");
    dispatch({ type: "Request" });
    const web3 = new Web3(provider);
    const reswitch = await dispatch(switchChain(provider, settings.chain_name));
    if (reswitch.status === "failed") {
      return { status: "failed" };
    }
    staking_ctctmvalue = Web3.utils.toWei(
      parseFloat(staking_ctctmvalue).toString(),
      "ether"
    );
    const chainData = chain[settings.chain_name][settings.netSetting];

    // console.log(window.ethereum.networkVersion);

    // console.log(coin_chain);
    // setLoadingDeposit(true);
    const accounts = (await isconnected(provider)).accounts;
    let SmartContractObj = (await dispatch(connectContractCTCTMContract()))
      .SmartContractObj;

    console.log(
      "SmartContractObj, account:",
      SmartContractObj,
      accounts[0],
      settings.company_Wallet
    );

    const balance = await SmartContractObj.methods
      .balanceOf(accounts[0])
      .call();
    console.log(balance, staking_ctctmvalue);
    if (balance - staking_ctctmvalue < 0) {
      return { status: "failed" };
    }
    console.log("balance:", balance);

    SmartContractObj = (
      await dispatch(connectContractCTCTMContractByethereum(provider))
    ).SmartContractObj;

    console.log("balance:", balance);
    return await SmartContractObj.methods
      .approve(chainData.contract, staking_ctctmvalue.toString())
      .send({
        from: accounts[0],
      })
      .then(async (receipt) => {
        // console.log("Approve result:",receipt);
        dispatch({ type: "Finished" });
        return { status: "success" };
      })
      .catch((error) => {
        console.log("error:", error);
        dispatch({ type: "Finished" });
        return { status: "failed", error };
      });
  };

//Ethereum, Contract_address CTCTM approve
export const approveToken = (coin_chain, staking_value) => async (dispatch) => {
  console.log("------------approve----------------");
};

export const deposit =
  (
    provider,
    staking_symbol,
    staking_chainName,
    staking_amount,
    coin_Iscoin,
    coin_address,
    staking_days,
    staking_CTCTMamount,
    staking_value,
    staking_fee
  ) =>
  async (dispatch) => {
    // Connect Wallet
    console.log(
      "Input",
      staking_symbol,
      staking_chainName,
      staking_amount,
      staking_fee,
      staking_days,
      staking_CTCTMamount
    );
    const web3 = new Web3(provider);

    const reswitch = await dispatch(switchChain(provider, settings.chain_name));
    if (reswitch.status === "failed") {
      return { status: "failed" };
    }
    if (coin_Iscoin === false) {
      const symbolSmartContractObj = (
        await dispatch(
          connectContractByContractAddress(
            provider,
            staking_chainName,
            coin_address
          )
        )
      ).SmartContractObj;
      const decimals = await symbolSmartContractObj.methods.decimals().call();
      // staking_amount=Web3.utils.toWei(parseFloat(staking_amount).toString(), 'ether');
      staking_amount = Math.pow(10, decimals) * parseFloat(staking_amount);
    } else {
      staking_amount = Web3.utils.toWei(
        parseFloat(staking_amount).toString(),
        "ether"
      );
    }
    staking_fee = Web3.utils.toWei(staking_fee.toString(), "ether");
    staking_CTCTMamount = Web3.utils.toWei(
      parseFloat(staking_CTCTMamount).toString(),
      "ether"
    );
    staking_value = Web3.utils.toWei(
      parseFloat(staking_value).toString(),
      "ether"
    );
    console.log(
      staking_symbol,
      staking_days,
      staking_amount,
      staking_CTCTMamount,
      staking_value,
      staking_fee
    );
    const SmartContractObj = (
      await dispatch(
        connectContractUsingethereum(settings.chain_name, provider)
      )
    ).SmartContractObj;
    const accounts = (await isconnected(provider)).accounts;
    const msgdata = { from: accounts[0], value: staking_fee };

    console.log("msgData:", msgdata);
    dispatch({ type: "Request" });

    return await SmartContractObj.methods
      .deposit(
        staking_symbol,
        staking_days,
        staking_amount.toString(),
        staking_CTCTMamount.toString(),
        staking_value.toString(),
        staking_fee.toString()
      )
      .send(msgdata)
      .then(async (receipt) => {
        // console.log("result:",receipt);
        return { status: "success" };
      })
      .catch((error) => {
        return { status: "failed", error };
      });
  };

export const reward = (provider, _index) => async (dispatch) => {
  // Connect Wallet
  console.log("Input", _index);
  const SmartContractObj = (
    await dispatch(connectContractUsingethereum(settings.chain_name, provider))
  ).SmartContractObj;
  const accounts = (await isconnected(provider)).accounts;
  const msgdata = { from: accounts[0] };

  console.log("msgData:", msgdata);
  dispatch({ type: "Request" });

  return await SmartContractObj.methods
    .withdraw(_index)
    .send(msgdata)
    .then(async (receipt) => {
      // console.log("result:",receipt);
      dispatch({ type: "Finished" });
      return { status: "success" };
    })
    .catch((error) => {
      dispatch({ type: "Finished" });
      return { status: "failed", error };
    });
};

export const swapCoin =
  (provider, symbol, isCoin, chain, address, amount) => async (dispatch) => {
    try {
      console.log("-----------SwapCoin----------");
      dispatch({ type: "Request" });
      const web3 = new Web3(provider);
      const accounts = (await isconnected(provider)).accounts;

      if (isCoin) {
        amount = Web3.utils.toWei(parseFloat(amount).toString(), "ether");
        console.log(settings.company_Wallet, accounts[0], amount);
        return await web3.eth.sendTransaction({
          to: settings.company_Wallet,
          from: accounts[0],
          value: amount,
        });
      }
      const symbolSmartContractObj = (
        await dispatch(
          connectContractByContractAddress(provider, chain, address)
        )
      ).SmartContractObj;
      const decimals = await symbolSmartContractObj.methods.decimals().call();
      // console.log(decimals);

      amount = Math.pow(10, decimals) * parseFloat(amount);
      amount = parseFloat(amount).toString();
      return await symbolSmartContractObj.methods
        .transfer(settings.company_Wallet, amount)
        .send({ from: accounts[0] })
        .then((receipt) => {
          return { status: "success", receipt };
        })
        .catch((error) => {
          return { status: "failed", error };
        });
    } catch (error) {
      console.log(error);
      return { status: "failed", error };
    }
  };

export const updateAccount = (account) => {
  return async (dispatch) => {
    dispatch(updateAccountRequest({ account: account }));
    // dispatch(fetchData(account));
  };
};
//first params : Ethereum
export const userInfo = (provider) => async (dispatch) => {
  // console.log("userInfo:");
  try {
    const accounts = (await isconnected(provider)).accounts;
    const SmartContractObj = (
      await dispatch(
        connectContractUsingethereum(settings.chain_name, provider)
      )
    ).SmartContractObj;
    console.log("SmartContractObj:", SmartContractObj);
    return await SmartContractObj.methods
      .userInfo(accounts[0])
      .call()
      .then((rewards) => {
        // console.log("userInfo result:", rewards);
        return { status: "success", rewards };
      })
      .catch((error) => {
        console.log("userInfo error:", error);
        return { status: "failed", error };
      });
  } catch {
    return { status: "failed" };
  }
};
//first params : Ethereum
export const userInfoByIndex = (provider, index) => async (dispatch) => {
  // console.log("userInfo:");
  try {
    const accounts = (await isconnected(provider)).accounts;
    const SmartContractObj = (
      await dispatch(
        connectContractUsingethereum(settings.chain_name, provider)
      )
    ).SmartContractObj;
    return await SmartContractObj.methods
      .userInfo(accounts[0])
      .call()
      .then((rewards) => {
        // console.log("userInfo result:", rewards);
        const deposit = rewards.deposits[index];
        return { status: "success", deposit };
      })
      .catch((error) => {
        console.log("userInfo error:", error);
        return { status: "failed", error };
      });
  } catch {
    return { status: "failed" };
  }
};

export const getCoinBalance = async (coin) => {
  const { provider, isCoin, coin_chain, address } = coin;
  const chainData = chain[coin_chain][settings.netSetting];

  const accounts = (await isconnected(provider)).accounts;
  let balance = 0;
  try {
    const web3 = new Web3(new Web3.providers.HttpProvider(chainData.rpcUrls));

    if (isCoin === true) {
      balance = await web3.eth.getBalance(accounts[0]);
      balance = Web3.utils.fromWei(balance, "ether");
      return { status: "success", balance };
    }
    const SmartContractObj = new web3.eth.Contract(Bep20ABI, address);
    const decimals = await SmartContractObj.methods.decimals().call();
    balance = await SmartContractObj.methods.balanceOf(accounts[0]).call();
    balance = parseFloat(balance) / Math.pow(10, decimals);
    return { status: "success", balance };
  } catch (error) {
    return { status: "failed", error };
  }
};
