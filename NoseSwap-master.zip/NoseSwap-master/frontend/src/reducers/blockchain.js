const initialState = {
  loading: false,
  account: null,
  smartContract: null,
  web3: null,
  provider: null,
  errorMsg: "",
};

const blockchainReducer = (state = initialState, action) => {
  const { type, payload } = action;

  switch (type) {
    case "CONNECTION_REQUEST":
      return {
        ...state,
        loading: true,
      };
    case "CONNECTION_PROVIDER":
      return {
        ...state,
        provider: payload.provider,
      };
    case "CONNECTION_SUCCESS":
      return {
        ...state,
        account: payload.account,
        smartContract: payload.smartContract,
        web3: payload.web3,
        loading: false,
      };
    case "CONNECTION_FAILED":
      return {
        ...state,
        errorMsg: payload.errorMsg,
      };
    case "UPDATE_ACCOUNT":
      return {
        ...state,
        account: payload.account,
      };
    case "CONNECTION_ChainChanged":
      return {
        ...state,
        errorMsg: payload.errorMsg,
      };
    case "Disconnect":
      return {
        ...state,
        loading: false,
      };
    case "Request":
      return {
        ...state,
        loading: true,
      };
    case "Finished":
      return {
        ...state,
        loading: false,
      };
    case "LOGOUT":
      return {
        ...state,
        loading: false,
        account: null,
        smartContract: null,
        web3: null,
        errorMsg: "",
      };
    default:
      return state;
  }
};

export default blockchainReducer;
