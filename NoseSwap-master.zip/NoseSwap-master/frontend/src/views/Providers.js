import React from 'react';

import Title from '../components/common/title/Title';
import StakingProviders from '../components/section/Providers';

function Providers(props) {
    return (
        <>
            <div className="">

                <Title 
                    title={"Staking Providers We Love."}
                    subTitle={<>
                        <p className='text-white text-center'></p>
                    </>}
                />
                
                <div className="bg-third">
                    <div className="n-container">
                        <StakingProviders />
                    </div>
                </div>
                
            </div>
        </>
    );
}

export default Providers;
