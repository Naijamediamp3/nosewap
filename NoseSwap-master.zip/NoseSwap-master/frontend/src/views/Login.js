import React, { useEffect, useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import Title from "../components/common/title/Title";
import { connect } from "../actions/blockchain";
import { login, logout } from "../actions/auth";

import Web3 from "web3";
import Web3Modal from "web3modal";
// import WalletLink from 'walletlink'

import { notify } from "../components/common/common";
import { ToastContainer } from "react-toastify";

// This function detects most providers injected at window.ethereum
import detectEthereumProvider from "@metamask/detect-provider";
import WalletConnectProvider from "@walletconnect/web3-provider";

const Login = () => {
  const dispatch = useDispatch();
  const blockchain = useSelector((state) => state.blockchain);
  const loading = useSelector((state) => state.blockchain.loading);
  const navigate = useNavigate();

  const [email, setEmail] = useState();
  const [password, setPassword] = useState();
  const [check, setCheck] = useState("");

  const onSignin = async (e) => {
    const INFURA_ID = "9a06afffd9994e19a25b9c505e96aace";

    const providerOptions = {
      walletconnect: {
        package: WalletConnectProvider, // required
        options: {
          infuraId: INFURA_ID, // required
        },
      },
    };
    let web3Modal;
    if (typeof window !== "undefined") {
      web3Modal = new Web3Modal({
        network: "mainnet", // optional
        providerOptions, // required
        cacheProvider: true,
      });
    }
    const provider = await web3Modal.connect();
    await provider.enable();

    // provider.on("accountsChanged", (accounts) => {
    //   notify(300, "Account was changed with " + accounts[0]);
    //   // alert("accounts:" + accounts[0]);
    // });

    // // Subscribe to chainId change
    // provider.on("chainChanged", (chainId) => {
    //   notify(300, "Chain was changed with " + chainId);
    //   // alert("chainID:" + chainId);
    // });

    // // Subscribe to session disconnection
    // provider.on("disconnect", (code, reason) => {
    //   notify(500, "Disconnected");
    //   // alert(code);
    // });

    dispatch({ type: "CONNECTION_PROVIDER", payload: { provider: provider } });
    e.preventDefault();

    ConnectWalletUsingWC(provider);
  };
  const ConnectWallet = async (provider) => {
    console.log("-----connect function------");
    dispatch({ type: "Request" });
    const res = await dispatch(connect(provider));
    return res;
  };

  const ConnectWalletUsingWC = async (provider) => {
    if (check === false) {
      // alert("Checked");
      dispatch({ type: "Finished" });
      notify(400, "Please check!");
      return;
    }
    if (!blockchain.account) {
      const res = await ConnectWallet(provider);
      console.log("connected:", res);
      if (res.status !== "success") {
        dispatch({ type: "Finished" });
        if (res.error === "metamask install") {
          notify(500, "Please Install metamask!");
          return;
        }
        notify(400, "Please connect wallet!");
        return;
      }
    }
    dispatch({ type: "Request" });
    const res = await dispatch(login(email, password));
    dispatch({ type: "Finished" });
    if (res !== "success") {
      notify(500, "Login was failed");
      return;
    } else if (res === "success") {
      notify(200, "Login Success.");
      navigate("/providers");
    }
  };

  useEffect(() => {}, []);

  return (
    <>
      <div className="">
        <Title title={"Login"} />

        <div className="bg-third py-10">
          <div className="n-container">
            <div className="max-w-[400px] w-11/12 m-auto text-white">
              <div>
                <p>Email</p>
                <input
                  type={"text"}
                  placeholder="Enter email"
                  className="py-2 px-4 w-full bg-[#24303E] mt-2 rounded"
                  defaultValue={email}
                  onChange={(e) => {
                    setEmail(e.target.value);
                  }}
                />
              </div>

              <div className="mt-5">
                <p>Password</p>
                <input
                  type={"password"}
                  placeholder="Enter password"
                  className="py-2 px-4 w-full bg-[#24303E] mt-2 rounded"
                  defaultValue={password}
                  onChange={(e) => {
                    setPassword(e.target.value);
                  }}
                />
              </div>

              <div className="flex justify-between mt-5">
                <p className="text-sm items-center flex gap-1">
                  <label className="checkbox">
                    <input
                      type="checkbox"
                      onChange={(e) => {
                        setCheck(e.target.checked);
                      }}
                      checked
                    />
                    <span>Remember me</span>
                  </label>
                </p>
                {/* <p className="text-sm text-[#FFC5DD]">Forgot Password?</p> */}
              </div>

              {loading == false ? (
                <button
                  className="w-full bg-[#FFC5DD] text-white mt-5 h-10 rounded"
                  onClick={(e) => {
                    onSignin(e);
                  }}
                >
                  LOGIN
                </button>
              ) : (
                <button className="w-full bg-[#FFC5DD] text-white mt-5 h-10 rounded">
                  <svg
                    role="status"
                    className="inline w-7 h-7 mr-2 text-gray-200 animate-spin dark:text-gray-600"
                    viewBox="0 0 100 101"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M100 50.5908C100 78.2051 77.6142 100.591 50 100.591C22.3858 100.591 0 78.2051 0 50.5908C0 22.9766 22.3858 0.59082 50 0.59082C77.6142 0.59082 100 22.9766 100 50.5908ZM9.08144 50.5908C9.08144 73.1895 27.4013 91.5094 50 91.5094C72.5987 91.5094 90.9186 73.1895 90.9186 50.5908C90.9186 27.9921 72.5987 9.67226 50 9.67226C27.4013 9.67226 9.08144 27.9921 9.08144 50.5908Z"
                      fill="currentColor"
                    />
                    <path
                      d="M93.9676 39.0409C96.393 38.4038 97.8624 35.9116 97.0079 33.5539C95.2932 28.8227 92.871 24.3692 89.8167 20.348C85.8452 15.1192 80.8826 10.7238 75.2124 7.41289C69.5422 4.10194 63.2754 1.94025 56.7698 1.05124C51.7666 0.367541 46.6976 0.446843 41.7345 1.27873C39.2613 1.69328 37.813 4.19778 38.4501 6.62326C39.0873 9.04874 41.5694 10.4717 44.0505 10.1071C47.8511 9.54855 51.7191 9.52689 55.5402 10.0491C60.8642 10.7766 65.9928 12.5457 70.6331 15.2552C75.2735 17.9648 79.3347 21.5619 82.5849 25.841C84.9175 28.9121 86.7997 32.2913 88.1811 35.8758C89.083 38.2158 91.5421 39.6781 93.9676 39.0409Z"
                      fill="#1C64F2"
                    />
                  </svg>
                </button>
              )}

              {/* <div className="mt-5 flex items-center justify-between">
                                <hr className="w-2/5"/>
                                <p className="font-bold">OR</p>
                                <hr className="w-2/5"/>
                            </div>

                            <button className="w-full bg-white rounded flex h-10 justify-center items-center gap-2 mt-5 text-[#8C8C8C] p-2">
                                <img src="/img/google.png" alt="" className="h-8"  />
                                Login in with Google
                            </button>

                            <button className="w-full bg-[#FFC5DD] rounded flex h-10 justify-center items-center text-black gap-2 mt-5 p-2">
                                <img src="/img/talk.png" alt="" className="h-8"  />
                                Login in with Katao Talk
                            </button> */}

              <p className="text-white text-center mt-5">
                Don't have a account?{" "}
                <span className="text-[#F4BC1D]">
                  <Link to="/signup">Sign Up</Link>
                </span>
              </p>
            </div>
          </div>
        </div>
      </div>
      <ToastContainer />
    </>
  );
};

export default Login;
