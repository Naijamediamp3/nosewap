import { React, useState } from "react";

import Title from "./../components/common/title/Title";
import Deposit from "./wallet/deposit";
import WithDraw from "./wallet/withdraw";
import CoinInfo from "./wallet/coinInfo";

function MyWallet() {
  const [currentNav, setCurrentNav] = useState("Deposit history");

  const nav = [
    { type: "Deposit history" },
    { type: "Withdrawal history" },
    { type: "Coin Info" },
  ];

  return (
    <>
      <div className="">
        <Title title={"Trusted Data. Stakeable Assets."} />

        <div className="bg-third">
          <div className="n-container">
            <div className="py-10">
              <div className="text-sm font-medium text-center text-white border-b border-gray-200 dark:text-gray-400 dark:border-gray-700">
                <ul className="flex flex-wrap mb-5 justify-center">
                  {nav.map((nav) => {
                    return (
                      <li
                        className="mr-1 w-auto text-xs sm:text-base"
                        key={nav.type}
                      >
                        <a
                          onClick={() => setCurrentNav(nav.type)}
                          href="#"
                          className={`${
                            currentNav === nav.type
                              ? "border-b-2 border-[#F4BC1D]"
                              : ""
                          } inline-block p-4 rounded-t-lg hover:border-[#F4BC1D] dark:hover:text-gray-300`}
                        >
                          {nav.type}
                        </a>
                      </li>
                    );
                  })}
                </ul>
              </div>
              {currentNav === nav[0].type && <Deposit />}
              {currentNav === nav[1].type && <WithDraw />}
              {currentNav === nav[2].type && <CoinInfo />}
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default MyWallet;
