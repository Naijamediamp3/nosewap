import React, { useEffect, useState, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { useParams } from "react-router-dom";

import settings from "../../contracts/default.json";

import Web3 from "web3";

import Table from "../../components/common/table/Table";
import {
  connectWallet,
  userInfo,
  switchWallet,
} from "../../actions/blockchain";
import { AllCoinInfo } from "../../actions/coin";

import {
  convertETF,
  notify,
  numberWithCommas,
  formatter,
} from "../../components/common/common";

import Moment from "react-moment";

function WithDraw() {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const firstUpdate = useRef(true);
  const [withdraws, setWithdraws] = useState([]);
  const [rewards, setRewards] = useState([]);

  const [isTableLoading, setTableLoading] = useState(false);
  const provider = useSelector((state) => state.blockchain.provider);

  const getData = async () => {
    console.log("getData");
    setTableLoading(true);
    let resswitch = await dispatch(switchWallet(provider, settings.chain_name));
    if (resswitch.status !== "success") {
      notify(500, "Please, Switch Wallet");
      return;
    }
    const result = await connectWallet(provider);
    if (result.status !== "success") {
      console.log("alert:connect wallet");
      notify(500, "Please, Connect Wallet");
      return;
    }
    const twithdraws = [];
    const trewards = [];

    const allrewards = await dispatch(userInfo(provider));

    if (allrewards.status === "failed") {
      notify(500, "Reward: Failed");
      return;
    } else if (allrewards.status === "success") {
      console.log("rewardlist:");
      console.log(allrewards);
      // notify(200, "UserData: Success");
      const { withdraws } = allrewards.rewards;
      withdraws.forEach((withdraw) => {
        twithdraws.push(withdraw);
      });
      setWithdraws(twithdraws);
      const { deposits } = allrewards.rewards;
      deposits.forEach((reward) => {
        trewards.push(reward);
      });
      setRewards(trewards);
    }
    console.log("Get Rewards finished");
    setTableLoading(false);
  };
  useState(() => {
    if (firstUpdate.current) {
      getData();
      firstUpdate.current = false;
      return;
    }
  }, []);
  return (
    <>
      {/* <div className='mb-5'>
                <div className='form-row'>
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 sm:gap-4 mt-5 text-center">
                        <div className="flex justify-between text-white items-center p-2 mt-2">
                            <select className="flex justify-between text-white items-center bg-[#303F50] p-2 mt-2 width-100" defaultValue={"select"}>
                                <option value="select" disabled>Please Select</option>
                                <option value="hurr">Durr</option>
                            </select>
                        </div>
                        
                        <div className='flex justify-between text-white items-center p-2 mt-2 width-100'>
                            <input type="date" className="mt-auto bg-[#263240] border border-[#CACACA] rounded-3xl px-3 py-1 text-white w-full" />
                        </div>

                        <div className="flex justify-between text-white items-center p-2 mt-2 width-100 col-span-2 sm:col-span-1">
                            <button className="px-4 text-white h-10 bg-[#FFC5DD] rounded width-100 mt-[10px]">Search</button>
                        </div>
                    </div>
                </div>
            </div> */}

      <Table
        tHeadData={
          <tr className="text-left">
            <th className="text-center">#</th>
            <th className="text-center">Coin</th>
            <th className="text-center hidden sm:table-cell">
              Staking_Times (day)
            </th>
            <th className="text-center hidden sm:table-cell">
              Total Rewards (ether)
            </th>
            {/* <th className="text-center">Staking_Fee(ether)</th> */}
            <th className="text-center hidden sm:table-cell">Start Time</th>
            <th className="text-center">WithDraw Time</th>
            <th className="text-center">WithDraw Amount</th>
          </tr>
        }
        tBodyData={
          <>
            {isTableLoading ? (
              <tr>
                <td className="text-center" colSpan={8}>
                  <svg
                    role="status"
                    className="inline w-4 h-4 mr-2 text-gray-200 animate-spin dark:text-gray-600"
                    viewBox="0 0 100 101"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M100 50.5908C100 78.2051 77.6142 100.591 50 100.591C22.3858 100.591 0 78.2051 0 50.5908C0 22.9766 22.3858 0.59082 50 0.59082C77.6142 0.59082 100 22.9766 100 50.5908ZM9.08144 50.5908C9.08144 73.1895 27.4013 91.5094 50 91.5094C72.5987 91.5094 90.9186 73.1895 90.9186 50.5908C90.9186 27.9921 72.5987 9.67226 50 9.67226C27.4013 9.67226 9.08144 27.9921 9.08144 50.5908Z"
                      fill="currentColor"
                    />
                    <path
                      d="M93.9676 39.0409C96.393 38.4038 97.8624 35.9116 97.0079 33.5539C95.2932 28.8227 92.871 24.3692 89.8167 20.348C85.8452 15.1192 80.8826 10.7238 75.2124 7.41289C69.5422 4.10194 63.2754 1.94025 56.7698 1.05124C51.7666 0.367541 46.6976 0.446843 41.7345 1.27873C39.2613 1.69328 37.813 4.19778 38.4501 6.62326C39.0873 9.04874 41.5694 10.4717 44.0505 10.1071C47.8511 9.54855 51.7191 9.52689 55.5402 10.0491C60.8642 10.7766 65.9928 12.5457 70.6331 15.2552C75.2735 17.9648 79.3347 21.5619 82.5849 25.841C84.9175 28.9121 86.7997 32.2913 88.1811 35.8758C89.083 38.2158 91.5421 39.6781 93.9676 39.0409Z"
                      fill="#1C64F2"
                    />
                  </svg>
                  Loading...
                </td>
              </tr>
            ) : (
              <></>
            )}

            {!isTableLoading &&
              withdraws.map((withdraw, index) => {
                const time = new Date(rewards[withdraw.dep_index].time * 1000);
                const last_payout = new Date(
                  rewards[withdraw.dep_index].last_payout * 1000
                );
                last_payout.setDate(parseInt(last_payout.getDate()));
                // console.log(time, last_payout, time.getTime()===last_payout.getTime());
                const staked_val = Web3.utils.fromWei(
                  rewards[withdraw.dep_index].staked_val,
                  "ether"
                );
                let fee = Web3.utils.fromWei(
                  rewards[withdraw.dep_index].fee,
                  "ether"
                );
                const withdraw_time = new Date(withdraw.time * 1000);
                let withdraw_amount = Web3.utils.fromWei(
                  withdraw.amount,
                  "ether"
                );
                withdraw_amount = Number(withdraw_amount).toFixed(4);
                fee /= rewards[withdraw.dep_index].fee_divider;
                fee = convertETF(fee);
                fee = fee > 0.000001 ? fee : 0.0;
                return (
                  <tr key={index}>
                    <td className="text-center">{index + 1}</td>
                    <td className="text-center">
                      {rewards[withdraw.dep_index].coin_symbol}
                    </td>
                    <td className="text-center hidden sm:table-cell">
                      {numberWithCommas(rewards[withdraw.dep_index].tarif)}
                    </td>
                    <td className="text-center hidden sm:table-cell">
                      {formatter.format(staked_val)}
                    </td>
                    <td className="text-center hidden sm:table-cell">
                      <Moment format="YYYY.MM.DD">{time}</Moment>
                    </td>
                    <td className="text-center">
                      <Moment format="YYYY.MM.DD">{withdraw_time}</Moment>
                    </td>
                    <td className="text-center">
                      {formatter.format(withdraw_amount)}
                    </td>
                  </tr>
                );
              })}
          </>
        }
      />
    </>
  );
}

export default WithDraw;
