import React, { useEffect, useState, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { useParams } from "react-router-dom";

import Web3 from "web3";

import Table from "../../components/common/table/Table";
import { getCoinBalance, connectWallet } from "../../actions/blockchain";
import { AllCoinInfo } from "../../actions/coin";

import { convertETF, formatter, notify } from "../../components/common/common";

import Moment from "react-moment";

function CoinInfo() {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const firstUpdate = useRef(true);
  const [coins, setCoins] = useState([]);
  const [flag, setflag] = useState(false);

  const [isTableLoading, setTableLoading] = useState(false);
  const provider = useSelector((state) => state.blockchain.provider);

  const getData = async () => {
    console.log("getData");
    setTableLoading(true);
    const tcoins = [];
    const result = await connectWallet(provider);
    if (result.status !== "success") {
      console.log("alert:connect wallet");
      notify(500, "Please, Connect Wallet");
      return;
    }
    // blockchain.smartContract.methods.coinslength().call().then((len)=>{length=len});
    const allcoin = await dispatch(AllCoinInfo());

    if (allcoin.status !== 200) {
      notify(500, "Server Error");
      return;
    }

    await allcoin.data.forEach((coin) => {
      tcoins.push(coin);
    });
    await setCoins(tcoins);

    for (var i = 0; i < tcoins.length; i++) {
      const { isCoin, chain, address } = tcoins[i];
      const result = await getCoinBalance({
        provider: provider,
        isCoin: isCoin,
        coin_chain: chain,
        address: address,
      });
      tcoins[i].balance = result.balance;
      setflag(!flag);
      console.log(tcoins[i].balance);
      await setCoins(tcoins);
    }

    await tcoins.forEach(async (coin, index) => {});

    console.log("Get Rewards finished");
    setTableLoading(false);
  };
  useEffect(() => {
    console.log("-------------------");
    if (firstUpdate.current) {
      getData();
      firstUpdate.current = false;
      return;
    }
  }, []);
  return (
    <>
      {/* <div className='mb-5'>
                <div className='form-row'>
                    <div className="sm:grid grid-cols-2 gap-2 sm:gap-4 mt-5 text-center">
                        <div className="flex justify-between text-white items-center p-2 mt-2">
                            <select className="flex justify-between text-white items-center bg-[#303F50] p-2 mt-2 width-100" defaultValue={"select"}>
                                <option value="select" disabled>Please Select</option>
                                <option value="hurr">Durr</option>
                            </select>
                        </div>

                        <div className="flex justify-between text-white items-center p-2 mt-2 width-100 col-span-2 sm:col-span-1">
                            <button className="px-4 text-white h-10 bg-[#FFC5DD] rounded width-100 mt-[10px]">Search</button>
                        </div>
                    </div>
                </div>
            </div> */}

      <Table
        tHeadData={
          <tr className="text-left">
            <th className="text-center">#</th>
            <th className="text-center">Coin</th>
            <th className="text-center hidden sm:table-cell">CoinName</th>
            <th className="text-center hidden sm:table-cell">CoinChain</th>
            <th className="text-center">Balance (ETH)</th>
            <th className="text-center">Staking Fee</th>
          </tr>
        }
        tBodyData={
          <>
            {coins.map((coin, index) => {
              const balance = parseFloat(coin.balance).toFixed(2);
              return (
                <tr key={index}>
                  <td className="text-center">{index + 1}</td>
                  <td className="text-center">{coin.symbol}</td>
                  <td className="text-center hidden sm:table-cell">
                    {coin.name}
                  </td>
                  <td className="text-center hidden sm:table-cell">
                    {coin.chain}
                  </td>
                  <td className="text-center">
                    {balance !== "NaN" ? (
                      formatter.format(balance)
                    ) : (
                      <svg
                        role="status"
                        className="inline w-4 h-4 mr-2 text-gray-200 animate-spin dark:text-gray-600"
                        viewBox="0 0 100 101"
                        fill="none"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path
                          d="M100 50.5908C100 78.2051 77.6142 100.591 50 100.591C22.3858 100.591 0 78.2051 0 50.5908C0 22.9766 22.3858 0.59082 50 0.59082C77.6142 0.59082 100 22.9766 100 50.5908ZM9.08144 50.5908C9.08144 73.1895 27.4013 91.5094 50 91.5094C72.5987 91.5094 90.9186 73.1895 90.9186 50.5908C90.9186 27.9921 72.5987 9.67226 50 9.67226C27.4013 9.67226 9.08144 27.9921 9.08144 50.5908Z"
                          fill="currentColor"
                        />
                        <path
                          d="M93.9676 39.0409C96.393 38.4038 97.8624 35.9116 97.0079 33.5539C95.2932 28.8227 92.871 24.3692 89.8167 20.348C85.8452 15.1192 80.8826 10.7238 75.2124 7.41289C69.5422 4.10194 63.2754 1.94025 56.7698 1.05124C51.7666 0.367541 46.6976 0.446843 41.7345 1.27873C39.2613 1.69328 37.813 4.19778 38.4501 6.62326C39.0873 9.04874 41.5694 10.4717 44.0505 10.1071C47.8511 9.54855 51.7191 9.52689 55.5402 10.0491C60.8642 10.7766 65.9928 12.5457 70.6331 15.2552C75.2735 17.9648 79.3347 21.5619 82.5849 25.841C84.9175 28.9121 86.7997 32.2913 88.1811 35.8758C89.083 38.2158 91.5421 39.6781 93.9676 39.0409Z"
                          fill="#1C64F2"
                        />
                      </svg>
                    )}
                  </td>
                  <td className="text-center">{coin.fee}%</td>
                </tr>
              );
            })}
            {isTableLoading ? (
              <tr>
                <td className="text-center" colSpan={6}>
                  <svg
                    role="status"
                    className="inline w-4 h-4 mr-2 text-gray-200 animate-spin dark:text-gray-600"
                    viewBox="0 0 100 101"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M100 50.5908C100 78.2051 77.6142 100.591 50 100.591C22.3858 100.591 0 78.2051 0 50.5908C0 22.9766 22.3858 0.59082 50 0.59082C77.6142 0.59082 100 22.9766 100 50.5908ZM9.08144 50.5908C9.08144 73.1895 27.4013 91.5094 50 91.5094C72.5987 91.5094 90.9186 73.1895 90.9186 50.5908C90.9186 27.9921 72.5987 9.67226 50 9.67226C27.4013 9.67226 9.08144 27.9921 9.08144 50.5908Z"
                      fill="currentColor"
                    />
                    <path
                      d="M93.9676 39.0409C96.393 38.4038 97.8624 35.9116 97.0079 33.5539C95.2932 28.8227 92.871 24.3692 89.8167 20.348C85.8452 15.1192 80.8826 10.7238 75.2124 7.41289C69.5422 4.10194 63.2754 1.94025 56.7698 1.05124C51.7666 0.367541 46.6976 0.446843 41.7345 1.27873C39.2613 1.69328 37.813 4.19778 38.4501 6.62326C39.0873 9.04874 41.5694 10.4717 44.0505 10.1071C47.8511 9.54855 51.7191 9.52689 55.5402 10.0491C60.8642 10.7766 65.9928 12.5457 70.6331 15.2552C75.2735 17.9648 79.3347 21.5619 82.5849 25.841C84.9175 28.9121 86.7997 32.2913 88.1811 35.8758C89.083 38.2158 91.5421 39.6781 93.9676 39.0409Z"
                      fill="#1C64F2"
                    />
                  </svg>
                  Loading...
                </td>
              </tr>
            ) : (
              <></>
            )}
          </>
        }
      />
    </>
  );
}

export default CoinInfo;
