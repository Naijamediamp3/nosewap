import React, { useEffect, useState, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { useParams } from "react-router-dom";

import Web3 from "web3";

import Title from "../components/common/title/Title";
// import Calculater from '../components/section/calculater/Calculater';
// import NewsLetter from '../components/section/NewsLetter';
// import PrivacySection from '../components/section/privacySection/PrivacySection';

import {
  switchWallet,
  isconnected,
  userInfoByIndex,
  reward,
} from "../actions/blockchain";
import { CoinInfoBySymbol } from "../actions/coin";

import Moment from "react-moment";

import { notify } from "../components/common/common";

import settings from "../contracts/default.json";

function Staking() {
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const { id } = useParams();
  const [deposit, setDeposit] = useState([]);
  const [coin, setCoin] = useState([]);
  const blockchain = useSelector((state) => state.blockchain);
  const isAuthenticated = useSelector((state) => state.auth.isAuthenticated);
  const loading = useSelector((state) => state.blockchain.loading);
  const provider = useSelector((state) => state.blockchain.provider);

  const [staking_amount, setStakingAmount] = useState(0);
  const [staking_days, setStakingDays] = useState(1000);
  const [staking_value, setStakingValue] = useState(0);
  const [staking_fee, setStakingFee] = useState(0);

  const [lastrewardamount, setLastRewardAmount] = useState(0);
  const [lastrewardday, setLastRewardDay] = useState(0);
  const [isConnected, SetIsConnected] = useState(false);
  const firstUpdate = useRef(true);

  const onReward = async () => {
    console.log("-----------------Reward----------------");
    const tnow = new Date();
    const diff = Math.trunc((tnow - lastrewardday) / (1000 * 60 * 60 * 24));
    if (diff < 1) {
      notify(500, "Reward time is less than 1 day");
      return;
    }
    console.log(tnow, lastrewardday, tnow - lastrewardday);
    const result = await dispatch(reward(id));

    if (result.status === "success") {
      notify(200, "Reward your token: Success");
    } else if (result.status === "failed") {
      notify(500, "Reward your token: Failed");
    }
    console.log("----------------/Reward/---------------");
  };

  const onConnectWallet = async () => {
    console.log("----------OnConnectWallet-----------");
    const result = await dispatch(switchWallet(provider, settings.chain_name));

    if (result.status === "success") {
      notify(200, "Switch Wallet-Success");
      SetIsConnected(true);
    } else if (result.status === "failed") {
      notify(500, "Switch Wallet-Failed");
      SetIsConnected(false);
    }
  };

  const getData = async () => {
    const trewards = [];
    const tcoins = [];
    // blockchain.smartContract.methods.coinslength().call().then((len)=>{length=len});
    const resultdeposit = await dispatch(userInfoByIndex(provider, id));

    if (resultdeposit.status === "failed") {
      notify(500, "UserData: Failed");
      return;
    } else if (resultdeposit.status === "success") {
      const { deposit } = resultdeposit;
      const resultcoin = await dispatch(
        CoinInfoBySymbol({ symbol: deposit.coin_symbol })
      );
      if (resultcoin.status !== 200) {
        notify(500, "UserData: Failed");
        return;
      }
      // notify(200, "UserData: Success");
      setDeposit(deposit);
      setCoin(resultcoin.data);

      setLastRewardAmount(Web3.utils.fromWei(deposit.last_staked_val, "ether"));
      setLastRewardDay(new Date(deposit.last_payout * 1000));
    }
    console.log("Get Deposit finished");
  };

  const getIsconnected = async () => {
    const result = await isconnected(provider);
    if (result.status === "success" && isConnected === false) {
      // notify(200,"Connected: Success");
      SetIsConnected(true);
      console.log("status:", isConnected);
    }
  };

  useEffect(() => {}, []);

  useEffect(() => {
    getData();
  }, [id]);

  useEffect(() => {
    if (firstUpdate.current) {
      onConnectWallet();
      getIsconnected();
      firstUpdate.current = false;
      return;
    }
  }, []);

  useEffect(() => {
    if (isAuthenticated === false) navigate("/login");
  }, [isAuthenticated]);

  return (
    <>
      <div className="">
        <Title
          title={`${coin.symbol} Reward`}
          subTitle={
            <>
              {/* <p className='text-white text-center'>We’re committed to protecting and respecting your privacy. We use your data to provide and improve the Service only.</p> */}
            </>
          }
        />
        <div className="bg-third py-10">
          <div className="n-container">
            <div className="text-white">
              <p className="text-right">Reward: CTC7</p>
            </div>
            <div className="w-10/12 m-auto text-white sm:grid grid-cols-2 gap-10 mt-5 mb-10">
              <div>
                <p> Last_Reward_Day </p>
                <p className="py-2 px-4 w-full bg-[#24303E] mt-2 rounded">
                  <Moment format="YYYY.MM.DD hh:mm:ss">{lastrewardday}</Moment>
                </p>
              </div>
              <div className="mt-10 sm:mt-0">
                <p> Total compensation </p>
                <input
                  type={"text"}
                  id={"amount"}
                  placeholder="Enter the amount"
                  className="py-2 px-4 w-full bg-[#24303E] mt-2 rounded"
                  value={parseFloat(lastrewardamount).toFixed(2) + " ether"}
                  disabled
                />
              </div>
            </div>

            <div className="text-center">
              {loading === false && (
                <input
                  type={"button"}
                  className="bg-[#FFC5DD] rounded px-3 py-1 font-bold text-dark w-100"
                  onClick={() => {
                    onReward();
                  }}
                  value={"Reward"}
                />
              )}
              {loading === true && (
                <input
                  type={"button"}
                  className="bg-[#FFC5DD] rounded px-3 py-1 font-bold text-dark w-100"
                  value={"..."}
                />
              )}
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default Staking;
