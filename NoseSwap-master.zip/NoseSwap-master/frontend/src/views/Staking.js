import React, { useEffect, useState, useRef } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { useParams } from "react-router-dom";

import Web3 from "web3";

import Title from "../components/common/title/Title";

import settings from "../contracts/default.json";
// import Calculater from '../components/section/calculater/Calculater';
// import NewsLetter from '../components/section/NewsLetter';
// import PrivacySection from '../components/section/privacySection/PrivacySection';

import {
  connectContract,
  approve,
  deposit,
  switchWallet,
  isconnected,
  Isallowance,
  swapCoin,
} from "../actions/blockchain";
import {
  CoinInfoBySymbol,
  calcFeeBySymbol,
  addStakingValue,
  addCTCTM,
} from "../actions/coin";
import {
  convertETF,
  notify,
  numberWithCommas,
  formatter,
} from "../components/common/common";

import Modal from "../components/common/modal/modal";
import checkmark from "../components/common/modal/checkmark-red.svg";

function Staking() {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const stakingbutton = useRef();

  const { symbol } = useParams();
  const [coinName, setCoinName] = useState("");
  const [coinchain, setCoinChain] = useState("");
  const [WalletName, setCoinWalletName] = useState("ethereum");
  const [isCoin, setCoinIsCoin] = useState(false);
  const [isApprove, setIsApprove] = useState(false);
  const [isSwap, setIsSwap] = useState(false);
  const [isStake, setIsStake] = useState(false);
  const [coinaddress, setCoinAddress] = useState(
    "0x00000000000000000000000000000000"
  );
  const [staked_value, setCoinStakedValue] = useState(0);
  const [users, setCoinUsers] = useState(0);
  const [country, setCoinCountry] = useState("");
  const [fee, setCoinFee] = useState(0);
  const [accounts, setAccounts] = useState([]);
  const index = 0;
  const blockchain = useSelector((state) => state.blockchain);
  const isAuthenticated = useSelector((state) => state.auth.isAuthenticated);
  const loading = useSelector((state) => state.blockchain.loading);
  const provider = useSelector((state) => state.blockchain.provider);

  const [staking_amount, setStakingAmount] = useState(0);
  const [staking_days, setStakingDays] = useState(1000);
  const [staking_value, setStakingValue] = useState(0);
  const [staking_fee, setStakingFee] = useState(0);
  const [staking_ctctmvalue, setStakingCTCTMValue] = useState(0);
  const [isConnected, SetIsConnected] = useState(false);
  const firstUpdate = useRef(true);

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [flag, setflag] = useState(false);

  const toggleModal = () => {
    if (parseFloat(staking_amount) === 0) {
      notify(400, "Please enter amount correctly.");
      return;
    }
    console.log("toggleModal");
    setIsModalOpen(!isModalOpen);
  };

  const onChanged = (e) => {
    if (e.target.id === "amount") {
      var newValue = e.target.value;
      if (newValue === "") newValue = "0";
      newValue = newValue.replace(new RegExp(/[^0-9.]/g), "");
      e.target.value = newValue;
      setStakingAmount(parseFloat(e.target.value));
    } else if (e.target.id === "days") {
      setStakingDays(parseFloat(e.target.value));
    }
  };

  const onStake = async () => {
    if (staking_amount === 0) {
      notify(500, "Input Staking Amount");
      return;
    }
    console.log("-----------------Stake----------------");
    const result = await dispatch(
      deposit(
        provider,
        symbol,
        coinchain,
        staking_amount,
        isCoin,
        coinaddress,
        staking_days,
        staking_ctctmvalue,
        staking_value,
        staking_fee
      )
    );

    if (result.status === "success") {
      const resultStaking = await dispatch(
        addStakingValue({ address: blockchain.account, symbol, staking_amount })
      );
      if (resultStaking.status === 200) {
        setIsStake(true);
        setIsModalOpen(!isModalOpen);
        notify(200, "Deposit your token: Success");
        return;
      }
      notify(500, "Deposit your token: Success, Server Error");
    } else if (result.status === "failed") {
      notify(500, "Deposit your token: Failed");
    }
    dispatch({ type: "Finished" });
    console.log("----------------/Stake/---------------");
  };

  const onApprove = async () => {
    if (staking_amount === 0) {
      notify(500, "Input Staking Amount");
      return;
    }
    console.log("-----------------Approve----------------");

    const result = await dispatch(
      approve(provider, coinchain, staking_ctctmvalue)
    );
    if (result.status === "success") {
      notify(200, "Approve Token:Success");
      setIsApprove(true);
    } else if (result.status === "failed") {
      notify(500, "Approve Token:failed");
    }
    dispatch({ type: "Finished" });
    console.log("----------------/Approve/---------------");
  };

  const onSwap = async () => {
    if (parseFloat(staking_amount) === 0) {
      notify(500, "Staking Amount: Zero");
      return;
    }
    let reswitch = await dispatch(switchWallet(provider, coinchain));
    console.log("Switch:", reswitch);
    const reswap = await dispatch(
      swapCoin(provider, symbol, isCoin, coinchain, coinaddress, staking_amount)
    );
    if (reswap.status === "failed") {
      notify(500, "Swap: BlockChain Error");
      dispatch({ type: "Finished" });
      return;
    }
    const resaccounts = (await isconnected(provider)).accounts;
    const resaddCTM = await dispatch(
      addCTCTM({ account: resaccounts[0], value: staking_amount * 5 })
    );
    if (resaddCTM.status !== 200) {
      notify(500, "Swap: SerVer Error");
      dispatch({ type: "Finished" });
      return;
    }

    notify(200, "Swap: Success");
    dispatch({ type: "Finished" });
    setIsSwap(true);

    reswitch = await dispatch(switchWallet(provider, settings.chain_name));
  };

  const onStart = async () => {
    console.log(staking_ctctmvalue);
    await calcFee();
    if (isAuthenticated === false) {
      notify(500, "Please, Login first");
      return;
    }
    if (isConnected === false) {
      notify(500, "Please, Connect wallet first");
      return;
    }
    if (symbol === "CTC(TM)") {
      setIsSwap(true);
    }
    toggleModal();
  };

  const onConnectWallet = async () => {
    console.log("----------OnConnectWallet-----------");
    const result = await dispatch(switchWallet(provider, coinchain));

    if (result.status === "success" && result.powerstatus !== "success") {
      notify(200, "Switch Wallet-Success");
      SetIsConnected(true);
    } else if (result.status === "success") {
      SetIsConnected(true);
    } else if (result.status === "failed") {
      dispatch({
        type: "CONNECTION_FAILED",
        payload: { errorMsg: "Chain changed" },
      });
      // navigate('/providers');
      SetIsConnected(false);
    }
  };

  const connect = async () => {
    if (coinchain === "") return;
    console.log("----blockchain----");
    const result = await dispatch(connectContract(coinchain, provider));

    if (result.status === "success") {
      notify(200, "Connect Smart Contract-Success");
    } else if (result.status === "failed") {
      notify(500, "Connect Smart Contract-Failed");
    }

    // console.log("smartContract:",smartContract);
  };

  const getData = async () => {
    console.log("---------------------coin----------------");
    const coinInfo = await dispatch(CoinInfoBySymbol({ symbol }));

    if (coinInfo.status !== 200) {
      notify(400, "Server Error");
      return;
    }

    const {
      name,
      chain,
      isCoin,
      WalletName,
      address,
      staked_value,
      users,
      country,
      fee,
    } = coinInfo.data;
    setCoinName(name);
    setCoinChain(chain);
    setCoinIsCoin(isCoin);
    setCoinWalletName(WalletName);
    setCoinAddress(address);
    setCoinStakedValue(staked_value);
    setCoinUsers(users);
    setCoinCountry(country);
    setCoinFee(fee);
  };

  const getIsconnected = async () => {
    const result = await isconnected();
    console.log("getIsconnected:", result);
    SetIsConnected(true);
    if (result.status === "success" && isConnected === false) {
      // notify(200,"Connected: Success");
      console.log("status:", isConnected);
    }
  };

  const calcFee = async () => {
    const result = await dispatch(calcFeeBySymbol({ symbol, staking_amount }));
    // console.log("coinchain:",coinchain, "symbol:", symbol, "staking_amount:", staking_amount);
    if (result.status === 400) {
      notify(400, "CalcFee: Failed");
      return;
    }
    let mul = 5;
    if (symbol === "CTC(TM)") {
      mul = 1;
    }
    setStakingCTCTMValue(staking_amount * mul);
    setStakingValue(result.data._staked_val);
    setStakingFee(convertETF(result.data._fee));

    setflag(!flag);
  };

  useEffect(() => {
    if (staking_amount <= 0) return;
    calcFee();
  }, [staking_amount]);

  useEffect(() => {
    if (coinchain !== "") onConnectWallet();
  }, [coinchain]);

  useEffect(() => {
    getData();
  }, [symbol]);

  useEffect(() => {
    console.log("current:", firstUpdate.current);
    if (isAuthenticated === false) {
      notify(500, "Please, Login First");
      return;
    }
    if (blockchain.smartContract === null) {
      connect();
      getIsconnected();
    }
  }, [isAuthenticated]);

  return (
    <>
      <div className="">
        <Title
          title={`${coinName} Staking`}
          subTitle={
            <>
              {/* <p className='text-white text-center'>We’re committed to protecting and respecting your privacy. We use your data to provide and improve the Service only.</p> */}
            </>
          }
        />
        <div className="bg-third py-10">
          <div className="n-container">
            {/* <div className='text-white'>
                            <p className='text-right'>Swap: CTCTM</p>
                        </div> */}
            <div className="w-10/12 m-auto text-white sm:grid grid-cols-2 gap-10 mt-5">
              <div>
                <div className="mb-10">
                  <div>
                    <p>
                      Enter the amount ({symbol})
                      <button className="float-right">max</button>
                    </p>
                    <input
                      type={"text"}
                      id={"amount"}
                      placeholder="Enter the amount"
                      className="py-2 px-4 w-full bg-[#24303E] mt-2 rounded"
                      onChange={(e) => {
                        onChanged(e);
                      }}
                      defaultValue={staking_amount}
                    />
                    <p className="float-right">
                      Converted CTCTM: {staking_ctctmvalue.toFixed(2)}
                    </p>
                  </div>
                </div>

                <div>
                  <p>Enter the staking times(day)</p>
                  <select
                    className="flex justify-between text-white items-center bg-[#303F50] p-2 mt-2 width-100"
                    id={"days"}
                    defaultValue={"1000"}
                    onChange={(e) => {
                      onChanged(e);
                    }}
                  >
                    <option value="1">1</option>
                    <option value="1000">1000</option>
                    <option value="2000">2000</option>
                    <option value="3000">3000</option>
                    <option value="4000">4000</option>
                  </select>
                </div>
              </div>
              <div className="mt-10 sm:mt-0">
                <div className="mb-10">
                  <p>Number of coins to be converted(ETH)</p>
                  <input
                    type={"text"}
                    placeholder="Staking value"
                    className="py-2 px-4 w-full bg-[#24303E] mt-2 rounded"
                    value={staking_value.toFixed(2)}
                    readOnly
                  />
                  <p className="float-right">
                    Staking Conversion Quantity 5x CTC(TM)
                  </p>
                </div>
                <div>
                  <p>Total Fee(BNB)</p>
                  <input
                    type={"text"}
                    placeholder="Fee value"
                    className="py-2 px-4 w-full bg-[#24303E] mt-2 rounded"
                    value={staking_fee}
                    readOnly
                  />
                </div>
              </div>
            </div>
            <div className="text-center mt-10">
              <div className="col-span-2 text-center w-[150px] m-auto">
                <input
                  type={"button"}
                  className="bg-[#FFC5DD] rounded px-3 py-1 font-bold text-dark w-[100%]"
                  onClick={() => {
                    onStart();
                  }}
                  value={"Swap"}
                />
              </div>
            </div>
          </div>
        </div>
      </div>

      <Modal
        show={isModalOpen}
        title="Staking Modal"
        close={toggleModal}
        isApprove={isApprove}
        isSwap={isSwap}
        loading={loading}
        onSwap={onSwap}
        onApprove={onApprove}
        onStake={onStake}
      >
        <p>
          {" "}
          <label className="text-header">1. Swap Ether to CTCTM</label>
          <label className="float-right">
            {isSwap ? (
              <img src={checkmark} alt="My Happy SVG" />
            ) : (
              <svg
                role="status"
                className="inline w-7 h-7 mr-2 text-gray-200 animate-spin dark:text-gray-600"
                viewBox="0 0 100 101"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M100 50.5908C100 78.2051 77.6142 100.591 50 100.591C22.3858 100.591 0 78.2051 0 50.5908C0 22.9766 22.3858 0.59082 50 0.59082C77.6142 0.59082 100 22.9766 100 50.5908ZM9.08144 50.5908C9.08144 73.1895 27.4013 91.5094 50 91.5094C72.5987 91.5094 90.9186 73.1895 90.9186 50.5908C90.9186 27.9921 72.5987 9.67226 50 9.67226C27.4013 9.67226 9.08144 27.9921 9.08144 50.5908Z"
                  fill="currentColor"
                />
                <path
                  d="M93.9676 39.0409C96.393 38.4038 97.8624 35.9116 97.0079 33.5539C95.2932 28.8227 92.871 24.3692 89.8167 20.348C85.8452 15.1192 80.8826 10.7238 75.2124 7.41289C69.5422 4.10194 63.2754 1.94025 56.7698 1.05124C51.7666 0.367541 46.6976 0.446843 41.7345 1.27873C39.2613 1.69328 37.813 4.19778 38.4501 6.62326C39.0873 9.04874 41.5694 10.4717 44.0505 10.1071C47.8511 9.54855 51.7191 9.52689 55.5402 10.0491C60.8642 10.7766 65.9928 12.5457 70.6331 15.2552C75.2735 17.9648 79.3347 21.5619 82.5849 25.841C84.9175 28.9121 86.7997 32.2913 88.1811 35.8758C89.083 38.2158 91.5421 39.6781 93.9676 39.0409Z"
                  fill="#1C64F2"
                />
              </svg>
            )}
          </label>
          <p className="text-content">
            You will get {staking_ctctmvalue} CTCTM to your wallet sending{" "}
            {staking_amount} Ether.
          </p>
        </p>
        <p>
          {" "}
          <label className="text-header">2. Approve CTCTM</label>
          <label className="float-right">
            {isApprove ? (
              <img src={checkmark} alt="My Happy SVG" />
            ) : (
              <svg
                role="status"
                className="inline w-7 h-7 mr-2 text-gray-200 animate-spin dark:text-gray-600"
                viewBox="0 0 100 101"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M100 50.5908C100 78.2051 77.6142 100.591 50 100.591C22.3858 100.591 0 78.2051 0 50.5908C0 22.9766 22.3858 0.59082 50 0.59082C77.6142 0.59082 100 22.9766 100 50.5908ZM9.08144 50.5908C9.08144 73.1895 27.4013 91.5094 50 91.5094C72.5987 91.5094 90.9186 73.1895 90.9186 50.5908C90.9186 27.9921 72.5987 9.67226 50 9.67226C27.4013 9.67226 9.08144 27.9921 9.08144 50.5908Z"
                  fill="currentColor"
                />
                <path
                  d="M93.9676 39.0409C96.393 38.4038 97.8624 35.9116 97.0079 33.5539C95.2932 28.8227 92.871 24.3692 89.8167 20.348C85.8452 15.1192 80.8826 10.7238 75.2124 7.41289C69.5422 4.10194 63.2754 1.94025 56.7698 1.05124C51.7666 0.367541 46.6976 0.446843 41.7345 1.27873C39.2613 1.69328 37.813 4.19778 38.4501 6.62326C39.0873 9.04874 41.5694 10.4717 44.0505 10.1071C47.8511 9.54855 51.7191 9.52689 55.5402 10.0491C60.8642 10.7766 65.9928 12.5457 70.6331 15.2552C75.2735 17.9648 79.3347 21.5619 82.5849 25.841C84.9175 28.9121 86.7997 32.2913 88.1811 35.8758C89.083 38.2158 91.5421 39.6781 93.9676 39.0409Z"
                  fill="#1C64F2"
                />
              </svg>
            )}
          </label>
          <p className="text-content">
            You will approve {staking_ctctmvalue} CTCTM to company wallet
          </p>
        </p>
        <p>
          {" "}
          <label className="text-header">3. Staking CTCTM</label>
          <label className="float-right">
            {isStake ? (
              <img src={checkmark} alt="My Happy SVG" />
            ) : (
              <svg
                role="status"
                className="inline w-7 h-7 mr-2 text-gray-200 animate-spin dark:text-gray-600"
                viewBox="0 0 100 101"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M100 50.5908C100 78.2051 77.6142 100.591 50 100.591C22.3858 100.591 0 78.2051 0 50.5908C0 22.9766 22.3858 0.59082 50 0.59082C77.6142 0.59082 100 22.9766 100 50.5908ZM9.08144 50.5908C9.08144 73.1895 27.4013 91.5094 50 91.5094C72.5987 91.5094 90.9186 73.1895 90.9186 50.5908C90.9186 27.9921 72.5987 9.67226 50 9.67226C27.4013 9.67226 9.08144 27.9921 9.08144 50.5908Z"
                  fill="currentColor"
                />
                <path
                  d="M93.9676 39.0409C96.393 38.4038 97.8624 35.9116 97.0079 33.5539C95.2932 28.8227 92.871 24.3692 89.8167 20.348C85.8452 15.1192 80.8826 10.7238 75.2124 7.41289C69.5422 4.10194 63.2754 1.94025 56.7698 1.05124C51.7666 0.367541 46.6976 0.446843 41.7345 1.27873C39.2613 1.69328 37.813 4.19778 38.4501 6.62326C39.0873 9.04874 41.5694 10.4717 44.0505 10.1071C47.8511 9.54855 51.7191 9.52689 55.5402 10.0491C60.8642 10.7766 65.9928 12.5457 70.6331 15.2552C75.2735 17.9648 79.3347 21.5619 82.5849 25.841C84.9175 28.9121 86.7997 32.2913 88.1811 35.8758C89.083 38.2158 91.5421 39.6781 93.9676 39.0409Z"
                  fill="#1C64F2"
                />
              </svg>
            )}
          </label>
          <p className="text-content">
            You will stake {staking_ctctmvalue} CTCTM.
          </p>
        </p>
      </Modal>
    </>
  );
}

export default Staking;
