import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Link } from "react-router-dom";
import { useDispatch } from "react-redux";
import { useSelector } from "react-redux";
import { logout } from "../../actions/auth";
import WalletIcon from "./42338-ff9800.svg";
import ProviderIcon from "./722073-ff9800.svg";
import { ToastContainer } from "react-toastify";

const Navbar = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const isAuthenticated = useSelector((state) => state.auth.isAuthenticated);
  // console.log("isAuthenticated:",isAuthenticated);
  const [isShow, toggleModal] = useState(false);

  const SignOut = () => {
    dispatch(logout());
    navigate("/login");
    toggleModal();
  };

  const Provider = () => {
    navigate("/providers");
    toggleModal();
  };

  const MyWallet = () => {
    navigate("/mywallet");
    toggleModal();
  };

  const Login = () => {
    navigate("/login");
    toggleModal();
  };

  const Signup = () => {
    navigate("/signup");
    toggleModal();
  };

  return (
    <>
      <div className="bg-[#171E26] py-3 z-20 border-b">
        <div className="n-container">
          <div className="flex justify-between items-center">
            <Link to={"/"}>
              <div className="flex items-center gap-5">
                <img src="/img/logo.svg" alt="logo" className="h-12 sm:h-16" />
                <div>
                  <p className="text-white fontweight-semibold text-3xl tracking-widest font-black fontfamily-poppins">
                    Nose Swap
                  </p>
                  {/* <p className="text-[#F29D20] tracking-tighter text-xs border-t-2 border-[#F29D20] font-medium">JUST THE RIGHT AMOUNT OF EVERYTHING</p> */}
                </div>
              </div>
            </Link>

            <div className="hidden sm:flex text-white gap-5">
              <Link to="/providers">
                <p>Staking Providers</p>
              </Link>
              <Link to="/mywallet">
                <p>My Wallet</p>
              </Link>
            </div>

            <div className="hidden sm:flex gap-5">
              {isAuthenticated === false && (
                <>
                  <Link to={"/signup"}>
                    <button className="border border-white h-10 px-2 text-white rounded">
                      Sign Up
                    </button>
                  </Link>
                  <Link to={"/login"}>
                    <button className="px-4 text-white h-10 bg-[#FFC5DD] rounded">
                      Login
                    </button>
                  </Link>
                </>
              )}
              {isAuthenticated === true && (
                <>
                  <button className="border border-white h-10 px-2 rounded">
                    <img src="/img/profile.png" alt="logo" />
                  </button>
                  <button
                    className="border border-white h-10 px-2 rounded"
                    onClick={() => SignOut()}
                  >
                    <img src="/img/logout.png" alt="logo" />
                  </button>
                </>
              )}
            </div>

            <p
              className="none sm:hidden text-white pointer text-right pointer mt-0 mr-0"
              onClick={() => toggleModal(true)}
            >
              &#9776;
            </p>
          </div>
        </div>

        <div
          className={` ${
            isShow ? "" : "hidden"
          } bg-secondary absolute right-0 top-0 h-screen float-right w-10/12 z-10`}
        >
          <p
            className="none sm:hidden text-white text-right pointer mt-6 mr-5"
            onClick={() => toggleModal(false)}
          >
            &#9776;
          </p>

          <div className="text-white text-left mt-10">
            <div
              className="mt-5 ml-5 flex items-center gap-5 text-[16px]"
              onClick={() => Provider()}
            >
              <img src={ProviderIcon} width={"18"} alt="provider" />
              Staking Providers
            </div>
            <div
              className="mt-5 ml-5 flex items-center gap-6 text-[16px]"
              onClick={() => MyWallet()}
            >
              <img src={WalletIcon} width={"16"} alt="wallet" />
              My Wallet
            </div>
            {isAuthenticated === true && (
              <div
                className="mt-5 ml-5 flex items-center gap-5 text-[16px]"
                onClick={() => SignOut()}
              >
                <img src="/img/logout.png" alt="logo" />
                Log Out
              </div>
            )}
          </div>

          {isAuthenticated === false && (
            <div className=" flex justify-center gap-5">
              <button
                className="bg-[#F4BC1D] py-1 px-6 mt-5 text-white rounded"
                onClick={() => {
                  Login();
                }}
              >
                Login
              </button>
              <button
                className="border border-white py-1 px-6 mt-5 text-white rounded"
                onClick={() => {
                  Signup();
                }}
              >
                Sign Up
              </button>
            </div>
          )}
        </div>
      </div>
      <ToastContainer />
    </>
  );
};

export default Navbar;
