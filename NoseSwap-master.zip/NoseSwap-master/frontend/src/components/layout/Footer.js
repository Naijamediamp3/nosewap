import React from "react";

import "./footer.css";

const Footer = () => {
  return (
    <>
      <div className="footer bg-primary">
        <div className="n-container">
          <div className="py-20 sm:flex justify-between gap-5">
            <div>
              <div className="flex items-center gap-2">
                <img src="/img/logo.svg" alt="logo" className="h-12 sm:h-16" />
                <div>
                  <p className="text-white fontweight-semibold text-3xl tracking-widest font-black fontfamily-poppins">
                    Nose Swap
                  </p>
                  {/* <p className="text-[#F29D20] tracking-tighter text-xs border-t-2 border-[#F29D20] font-medium">JUST THE RIGHT AMOUNT OF EVERYTHING</p> */}
                </div>
              </div>
            </div>

            <div className="mt-3">
              <h1 className="footer_title">Quick Links</h1>
              <hr className="solid" />
              <div className="mt-5">
                <p className="footer_text">- Staking Providers</p>
                <p className="footer_text">- My Wallet</p>
              </div>
            </div>

            <div className="mt-3">
              <h1 className="footer_title">Help</h1>
              <hr className="solid" />
              <div className="mt-5">
                <p className="footer_text">- Support</p>
                <p className="footer_text">- Teams & Conditions</p>
                <p className="footer_text">- Privacy Policy</p>
              </div>
            </div>

            <div className="mt-3">
              <h1 className="footer_title">Newsletter</h1>
              <hr className="solid" />
              <div className="mt-5">
                <p className="footer_text">
                  Duis aute irure dolor in reprehen derit in velit.
                </p>
              </div>

              <div className="flex items-center mt-5">
                <input
                  type="text"
                  className="bg-[#263240] border border-[#CACACA] rounded-3xl px-3 py-1 text-white w-full"
                  placeholder="Enter email address"
                />

                <img
                  src="/img/mail.png"
                  style={{ marginLeft: "-40px" }}
                  alt=""
                />
              </div>
            </div>
          </div>

          <div className="border-t border-white py-4 sm:flex justify-between items-center">
            <div className="flex gap-2 justify-center">
              <img src="/img/discord.png" alt="" />
              <img src="/img/facebook.png" alt="" />
              <img src="/img/twitter.png" alt="" />
              <img src="/img/instagram.png" alt="" />
            </div>
            <div className="text-center mt-2 sm:mt-0 sm:text-right">
              {/* <p className=" text-white">Copyright © 2022 Company Name. All Right Reserved</p> */}
              <p className="text-white">
                Designed and Developed by{" "}
                <a
                  href="https://raylancer.co"
                  className="text-decoration-none"
                  target="_blank"
                  rel="noreferrer"
                  style={{ color: "#CA9E67" }}
                >
                  raylancer.co
                </a>
              </p>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Footer;
