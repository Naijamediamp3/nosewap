import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";

import Table from "./../common/table/Table";
import StakingList from "./StakingList";
import RewardsList from "./RewardsList";
import { connectContract } from "../../actions/blockchain";
import { AllCoinInfo } from "../../actions/coin";

const StakingProviders = () => {
  const [currentNav, setCurrentNav] = useState("Staking");
  const nav = [{ type: "Staking" }, { type: "Rewards" }];

  return (
    <>
      <div className="cryptoAsset">
        <div className="py-10">
          <div className="text-sm font-medium text-center text-white border-b border-gray-200 dark:text-gray-400 dark:border-gray-700">
            <ul className="flex flex-wrap mb-5 justify-center">
              {nav.map((row) => {
                return (
                  <li className="mr-2 w-100" key={row.type}>
                    <a
                      onClick={() => setCurrentNav(row.type)}
                      href="#"
                      className={`${
                        currentNav === row.type
                          ? "border-b-2 border-[#F4BC1D]"
                          : ""
                      } inline-block p-4 rounded-t-lg hover:border-[#F4BC1D] dark:hover:text-gray-300`}
                    >
                      {row.type}
                    </a>
                  </li>
                );
              })}
            </ul>
          </div>

          {currentNav === nav[0].type && <StakingList />}
          {currentNav === nav[1].type && <RewardsList />}
        </div>
      </div>
    </>
  );
};

export default StakingProviders;
