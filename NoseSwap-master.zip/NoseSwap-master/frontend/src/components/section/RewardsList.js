import React, { useEffect, useState, useLayoutEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";

import Web3 from "web3";

import Table from "./../common/table/Table";
import { userInfo } from "../../actions/blockchain";
import { AllCoinInfo } from "../../actions/coin";

import {
  convertETF,
  notify,
  formatter,
  numberWithCommas,
} from "../common/common";

import Moment from "react-moment";

const RewardsList = () => {
  const dispatch = useDispatch();
  const isAuthenticated = useSelector((state) => state.auth.isAuthenticated);
  const provider = useSelector((state) => state.blockchain.provider);
  const blockchain = useSelector((state) => state.blockchain);
  const [rewards, setRewards] = useState([]);
  const [coins, setCoins] = useState([]);
  const firstUpdate = useRef(true);

  const [isTableLoading, setTableLoading] = useState(false);

  useEffect(() => {
    if (blockchain.smartContract === null || isAuthenticated === false) {
      navigate("/login");
    }
  }, []);

  useEffect(() => {
    if (isAuthenticated === true && blockchain.smartContract) {
      // notify(200);
    }
  }, [isAuthenticated, blockchain.smartContract]);

  const navigate = useNavigate();

  const onClickStake = (index) => {
    console.log("onclick");
    navigate(`/withdraw/${index}`);
  };

  const getData = async () => {
    const trewards = [];
    const tcoins = [];
    setTableLoading(true);
    // blockchain.smartContract.methods.coinslength().call().then((len)=>{length=len});
    const allcoin = await dispatch(AllCoinInfo());

    if (allcoin.status !== 200) {
      notify(500, "Server Error");
      return;
    }

    allcoin.data.forEach((coin) => {
      tcoins.push(coin);
    });
    // setCoins(tcoins);
    console.log("CoinInfo complecated");

    const allrewards = await dispatch(userInfo(provider));

    if (allrewards.status === "failed") {
      notify(500, "UserData: Failed");
      return;
    } else if (allrewards.status === "success") {
      console.log("rewardlist:");
      // notify(200, "UserData: Success");
      const { deposits } = allrewards.rewards;
      deposits.forEach((reward) => {
        trewards.push(reward);
      });
      setRewards(trewards);
    }
    console.log("Get Rewards finished");
    setTableLoading(false);
  };

  useLayoutEffect(() => {
    console.log("----------------Connected-----------------");
    if (firstUpdate.current) {
      getData();
      firstUpdate.current = false;
      return;
    }
  }, []);

  return (
    <>
      <Table
        tHeadData={
          <tr className="text-left">
            <th className="text-center hidden sm:table-cell">#</th>
            <th className="text-center">Coin</th>
            <th className="text-center hidden sm:table-cell">
              Staking Day (day)
            </th>
            {/* <th className="text-center">Amount(ETH)</th> */}
            <th className="text-center">Last Rewards (ETH)</th>
            <th className="text-center hidden sm:table-cell">
              Total Rewards (ETH)
            </th>
            {/* <th className="text-center">Staking_Fee(ETH)</th> */}
            <th className="text-center hidden sm:table-cell">Start Time</th>
            <th className="text-center">Last payout</th>
            <th className="text-center">Withdraw</th>
          </tr>
        }
        tBodyData={
          <>
            {isTableLoading ? (
              <tr>
                <td className="text-center" colSpan={8}>
                  <svg
                    role="status"
                    className="inline w-4 h-4 mr-2 text-gray-200 animate-spin dark:text-gray-600"
                    viewBox="0 0 100 101"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M100 50.5908C100 78.2051 77.6142 100.591 50 100.591C22.3858 100.591 0 78.2051 0 50.5908C0 22.9766 22.3858 0.59082 50 0.59082C77.6142 0.59082 100 22.9766 100 50.5908ZM9.08144 50.5908C9.08144 73.1895 27.4013 91.5094 50 91.5094C72.5987 91.5094 90.9186 73.1895 90.9186 50.5908C90.9186 27.9921 72.5987 9.67226 50 9.67226C27.4013 9.67226 9.08144 27.9921 9.08144 50.5908Z"
                      fill="currentColor"
                    />
                    <path
                      d="M93.9676 39.0409C96.393 38.4038 97.8624 35.9116 97.0079 33.5539C95.2932 28.8227 92.871 24.3692 89.8167 20.348C85.8452 15.1192 80.8826 10.7238 75.2124 7.41289C69.5422 4.10194 63.2754 1.94025 56.7698 1.05124C51.7666 0.367541 46.6976 0.446843 41.7345 1.27873C39.2613 1.69328 37.813 4.19778 38.4501 6.62326C39.0873 9.04874 41.5694 10.4717 44.0505 10.1071C47.8511 9.54855 51.7191 9.52689 55.5402 10.0491C60.8642 10.7766 65.9928 12.5457 70.6331 15.2552C75.2735 17.9648 79.3347 21.5619 82.5849 25.841C84.9175 28.9121 86.7997 32.2913 88.1811 35.8758C89.083 38.2158 91.5421 39.6781 93.9676 39.0409Z"
                      fill="#1C64F2"
                    />
                  </svg>
                  Loading...
                </td>
              </tr>
            ) : (
              <></>
            )}

            {!isTableLoading &&
              rewards.map((reward, index) => {
                const time = new Date(reward.time * 1000);
                const enddate = new Date(reward.time * 1000);
                enddate.setDate(
                  parseInt(enddate.getDate()) + parseInt(reward.tarif)
                );
                const last_payout = new Date(reward.last_payout * 1000);
                last_payout.setDate(parseInt(last_payout.getDate()));
                // console.log(time, last_payout, time.getTime()===last_payout.getTime());
                const amount = Web3.utils.fromWei(reward.amount, "ether");
                const last_staked_val = Number(
                  Web3.utils.fromWei(reward.last_staked_val, "ether")
                ).toFixed(2);
                const staked_val = Number(
                  Web3.utils.fromWei(reward.staked_val, "ether")
                ).toFixed(2);
                let fee = Web3.utils.fromWei(reward.fee, "ether");
                fee /= reward.fee_divider;
                fee = convertETF(fee);
                fee = fee > 0.000001 ? fee : 0.0;
                if (enddate.getTime() <= last_payout.getTime()) return;
                return (
                  <tr key={index}>
                    <td className="text-center hidden sm:table-cell">
                      {index + 1}
                    </td>
                    <td className="text-center">{reward.coin_symbol}</td>
                    <td className="text-center hidden sm:table-cell">
                      {numberWithCommas(reward.tarif)}
                    </td>
                    {/* <td className="text-center">{amount}</td> */}
                    <td className="text-center">{last_staked_val}</td>
                    <td className="text-center hidden sm:table-cell">
                      {staked_val}
                    </td>
                    {/* <td className="text-center">{fee}</td> */}
                    <td className="text-center hidden sm:table-cell">
                      <Moment format="YYYY.MM.DD">{time}</Moment>
                    </td>
                    <td className="text-center">
                      {time.getTime() === last_payout.getTime() ? (
                        ""
                      ) : (
                        <Moment format="YYYY.MM.DD">{last_payout}</Moment>
                      )}
                    </td>
                    <td className="text-center">
                      <button
                        className="bg-[#FFC5DD] rounded px-2 py-1 font-bold text-dark"
                        onClick={() => {
                          onClickStake(index);
                        }}
                      >
                        WithDraw
                      </button>
                    </td>
                  </tr>
                );
              })}
          </>
        }
      />
    </>
  );
};

export default RewardsList;
